# CS Quotes Pertaining to ML/AI

## Early CS

"The engine might compose elaborate and scientific pieces of music of any degree
of complexity or extent"
~ Ada Lovelace

"Trees sprout up just about everywhere in computer science"
~ Donald Knuth

"The question of whether a computer can think is no more interesting than the
question of whether a submarine can swim."
~ Edsger Dijkstra

## More Recent CS

"We are the hackers of abstraction. We produce  new concepts, new perceptions,
new sensations, hacked out of raw data"
~ McKenizie Wark

"We are irrational creatures who cannot adequately understand our own actions or
explain them in terms of rational principles."
~ Meghan O'Gieblyn

