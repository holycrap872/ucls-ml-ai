"The engine might compose elaborate and scientific pieces of music of any degree
of complexity or extent"
~ Ada Lovelace
